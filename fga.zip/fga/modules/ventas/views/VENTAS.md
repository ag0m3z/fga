# Modulo de Ventas

##### Estatus de Notas de venta <br>

<ol>
<li> Terminada</li>
<li> Pendiente </li>
<li> Cancelada </i>
</ol>
